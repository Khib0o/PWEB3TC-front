export interface Activities {
    title : String;
    date: String;
}