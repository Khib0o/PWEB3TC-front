import { Activities } from "./activities";

export const ACTIVITIES : Activities[] = [
    {title : 'Projet/main', date : "January 2022"},
    {title : 'Projet/component', date : "January 2022"},
    {title : 'Projet/header', date : "February 2022"},
    {title : 'Projet/auth', date : "February 2022"},
]
