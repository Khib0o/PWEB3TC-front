export interface deadLines {
    title : String;
    date : String;
}

export const DEADLINES : deadLines[] = [
    {title: "Compte-Rendu TPS 2" , date : "18/03/2022"},
    {title: "Projet Web" , date : "22/05/2022"},
    {title: "Projet PIR" , date : "17/06/2022"},
]