import { Team } from "./team";

export const TEAM : Team[] = [
    {code : '001', name : "Jiang Zhenglin"},
    {code : '002', name : "Tony Dinh"},
    {code : '003', name : "CHanbin Lee"},
    {code : '004', name : "Louis Teys"},
    {code : '005', name : "Jerbi Ghassen"},
    {code : '006', name : "Yanni Mansour"},
]
