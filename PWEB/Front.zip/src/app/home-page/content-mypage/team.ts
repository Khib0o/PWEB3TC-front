export interface Team {
    code : String;
    name: String;
}