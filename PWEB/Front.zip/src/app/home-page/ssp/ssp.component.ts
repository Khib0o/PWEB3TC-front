import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ssp',
  templateUrl: './ssp.component.html',
  styleUrls: ['./ssp.component.css']
})
export class SspComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
