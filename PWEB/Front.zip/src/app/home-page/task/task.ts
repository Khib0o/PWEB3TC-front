export interface Task {
    title : String,
    content : String
}