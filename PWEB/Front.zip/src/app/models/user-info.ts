export class UserInfo {
    token!: string
    id!: number
    name!: string
    url!: string
    email!: string
}